1. Download and install Python 3.7:
https://www.python.org/downloads/

2. Install all Requirements (command line):
pip install -r requirements.txt

3. Run (command line):
python timofeyev_vc.py
